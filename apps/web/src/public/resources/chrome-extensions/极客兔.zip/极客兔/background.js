/** @typedef {{ song: string, play_url: string, singer: string }} Track */

/** @type {Track[]} */
const PLAYLIST = [
  {
    song: '把回忆拼好给你',
    play_url:
      'https://www.zhouyu2156.cn/musics/%E6%8A%8A%E5%9B%9E%E5%BF%86%E6%8B%BC%E5%A5%BD%E7%BB%99%E4%BD%A0/%E6%8A%8A%E5%9B%9E%E5%BF%86%E6%8B%BC%E5%A5%BD%E7%BB%99%E4%BD%A0-%E5%B0%8F%E9%87%8E%E6%9D%A5%E4%BA%86.mp3',
    singer: '小野来了',
  },
  {
    song: '西海情歌',
    play_url:
      'https://www.zhouyu2156.cn/musics/%E8%A5%BF%E6%B5%B7%E6%83%85%E6%AD%8C/%E8%A5%BF%E6%B5%B7%E6%83%85%E6%AD%8C-%E5%88%80%E9%83%8E.mp3',
    singer: '刀郎',
  },
  {
    song: '爱是你我',
    play_url:
      'https://www.zhouyu2156.cn/musics/%E7%88%B1%E6%98%AF%E4%BD%A0%E6%88%91/%E7%88%B1%E6%98%AF%E4%BD%A0%E6%88%91-%E5%88%80%E9%83%8E%E3%80%81%E5%BE%90%E5%AD%90%E5%B0%A7.mp3',
    singer: '刀郎、徐子尧',
  },
]

const OFFSCREEN_PATH = 'offscreen.html'
const STORAGE_KEY = 'geekrabbitPlayer'

/** @type {{ index: number, paused: boolean, currentTime: number, duration: number }} */
let mirror = { index: 0, paused: true, currentTime: 0, duration: 0 }

async function persistMirror() {
  await chrome.storage.local.set({ [STORAGE_KEY]: { ...mirror } })
}

async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument()) return
  await chrome.offscreen.createDocument({
    url: chrome.runtime.getURL(OFFSCREEN_PATH),
    reasons: ['AUDIO_PLAYBACK'],
    justification: '在 popup 关闭后继续播放音乐。',
  })
  await new Promise((r) => setTimeout(r, 120))
}

/**
 * @param {object} payload
 */
function sendOffscreen(payload) {
  chrome.runtime.sendMessage({ target: 'offscreen', ...payload })
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.target === 'offscreen') return

  if (msg?.type === 'GET_STATE') {
    sendResponse({
      playlist: PLAYLIST,
      index: mirror.index,
      paused: mirror.paused,
      currentTime: mirror.currentTime,
      duration: mirror.duration,
    })
    return false
  }

  if (msg?.type === 'PLAY_INDEX') {
    const idx = Math.max(0, Math.min(PLAYLIST.length - 1, Number(msg.index) || 0))
    mirror.index = idx
    mirror.paused = false
    persistMirror()
    ensureOffscreen().then(() => {
      sendOffscreen({
        type: 'LOAD_PLAY',
        url: PLAYLIST[idx].play_url,
      })
    })
    sendResponse({ ok: true })
    return false
  }

  if (msg?.type === 'TOGGLE_PAUSE') {
    mirror.paused = !mirror.paused
    persistMirror()
    ensureOffscreen().then(() => {
      sendOffscreen({ type: mirror.paused ? 'PAUSE' : 'RESUME' })
    })
    sendResponse({ ok: true, paused: mirror.paused })
    return false
  }

  if (msg?.type === 'NEXT') {
    mirror.index = (mirror.index + 1) % PLAYLIST.length
    mirror.paused = false
    persistMirror()
    ensureOffscreen().then(() => {
      sendOffscreen({
        type: 'LOAD_PLAY',
        url: PLAYLIST[mirror.index].play_url,
      })
    })
    sendResponse({ ok: true, index: mirror.index })
    return false
  }

  if (msg?.type === 'PREV') {
    mirror.index = (mirror.index - 1 + PLAYLIST.length) % PLAYLIST.length
    mirror.paused = false
    persistMirror()
    ensureOffscreen().then(() => {
      sendOffscreen({
        type: 'LOAD_PLAY',
        url: PLAYLIST[mirror.index].play_url,
      })
    })
    sendResponse({ ok: true, index: mirror.index })
    return false
  }

  if (msg?.type === 'SEEK') {
    let t = Number(msg.time)
    if (!Number.isFinite(t)) {
      sendResponse({ ok: false })
      return false
    }
    if (mirror.duration > 0) {
      t = Math.max(0, Math.min(t, mirror.duration))
    }
    mirror.currentTime = t
    persistMirror()
    ensureOffscreen().then(() => {
      sendOffscreen({ type: 'SEEK', time: t })
    })
    sendResponse({ ok: true })
    return false
  }

  if (msg?.type === 'OFFSCREEN_SYNC') {
    mirror.currentTime = msg.currentTime ?? mirror.currentTime
    mirror.duration = msg.duration ?? mirror.duration
    if (typeof msg.paused === 'boolean') mirror.paused = msg.paused
    persistMirror()
    sendResponse({ ok: true })
    return false
  }

  if (msg?.type === 'TRACK_ENDED') {
    mirror.index = (mirror.index + 1) % PLAYLIST.length
    mirror.paused = false
    mirror.currentTime = 0
    persistMirror()
    ensureOffscreen().then(() => {
      sendOffscreen({
        type: 'LOAD_PLAY',
        url: PLAYLIST[mirror.index].play_url,
      })
    })
    sendResponse({ ok: true })
    return false
  }

  return false
})

chrome.runtime.onInstalled.addListener(() => {
  persistMirror()
})

chrome.storage.local.get(STORAGE_KEY, (data) => {
  const s = data[STORAGE_KEY]
  if (s && typeof s.index === 'number') {
    mirror = {
      index: s.index,
      paused: !!s.paused,
      currentTime: Number(s.currentTime) || 0,
      duration: Number(s.duration) || 0,
    }
  }
})
