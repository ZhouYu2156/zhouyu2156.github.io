const el = {
  nowSong: document.getElementById("nowSong"),
  nowSinger: document.getElementById("nowSinger"),
  seek: document.getElementById("seek"),
  tCur: document.getElementById("tCur"),
  tDur: document.getElementById("tDur"),
  btnPlay: document.getElementById("btnPlay"),
  iconPlay: document.getElementById("iconPlay"),
  iconPause: document.getElementById("iconPause"),
  btnPrev: document.getElementById("btnPrev"),
  btnNext: document.getElementById("btnNext"),
  trackList: document.getElementById("trackList"),
};

/** @type {{ song: string, play_url: string, singer: string }[]} */
let playlist = [];
let state = {
  index: 0,
  paused: true,
  currentTime: 0,
  duration: 0,
};

let seekDragging = false;

function fmtTime(sec) {
  if (!Number.isFinite(sec) || sec < 0) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function renderNow() {
  const t = playlist[state.index];
  if (t) {
    el.nowSong.textContent = t.song;
    el.nowSinger.textContent = t.singer;
  } else {
    el.nowSong.textContent = "—";
    el.nowSinger.textContent = "";
  }
  el.iconPlay.style.display = state.paused ? "block" : "none";
  el.iconPause.style.display = state.paused ? "none" : "block";
  el.tCur.textContent = fmtTime(state.currentTime);
  el.tDur.textContent = fmtTime(state.duration);
  const max = state.duration > 0 ? state.duration : 100;
  if (!seekDragging) {
    el.seek.max = String(max);
    el.seek.value = String(
      state.duration > 0 ? Math.min(state.currentTime, state.duration) : 0,
    );
  }
}

function renderList() {
  el.trackList.innerHTML = "";
  playlist.forEach((item, i) => {
    const li = document.createElement("li");
    if (i === state.index) li.classList.add("active");
    li.innerHTML = `<span>${item.song}</span><span class="s">${item.singer}</span>`;
    li.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "PLAY_INDEX", index: i }, refreshState);
    });
    el.trackList.appendChild(li);
  });
}

function refreshState() {
  chrome.runtime.sendMessage({ type: "GET_STATE" }, (res) => {
    if (chrome.runtime.lastError || !res) return;
    playlist = res.playlist || [];
    state.index = res.index ?? 0;
    state.paused = !!res.paused;
    state.currentTime = res.currentTime ?? 0;
    state.duration = res.duration ?? 0;
    renderNow();
    renderList();
  });
}

el.btnPlay.addEventListener("click", () => {
  if (!playlist.length) return;
  const needStart = state.paused && state.currentTime === 0 && state.duration === 0;
  if (needStart) {
    chrome.runtime.sendMessage(
      { type: "PLAY_INDEX", index: state.index },
      refreshState,
    );
    return;
  }
  chrome.runtime.sendMessage({ type: "TOGGLE_PAUSE" }, (res) => {
    if (res && typeof res.paused === "boolean") state.paused = res.paused;
    renderNow();
  });
});

el.btnPrev.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "PREV" }, refreshState);
});

el.btnNext.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "NEXT" }, refreshState);
});

el.seek.addEventListener("pointerdown", () => {
  seekDragging = true;
});

el.seek.addEventListener("pointercancel", () => {
  seekDragging = false;
});

el.seek.addEventListener("change", () => {
  const t = parseFloat(el.seek.value, 10);
  if (!Number.isFinite(t) || state.duration <= 0) {
    seekDragging = false;
    return;
  }
  const clamped = Math.max(0, Math.min(t, state.duration));
  chrome.runtime.sendMessage({ type: "SEEK", time: clamped }, () => {
    seekDragging = false;
    setTimeout(refreshState, 80);
  });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.geekrabbitPlayer) return;
  const n = changes.geekrabbitPlayer.newValue;
  if (!n) return;
  state.index = n.index ?? state.index;
  state.paused = !!n.paused;
  state.currentTime = n.currentTime ?? state.currentTime;
  state.duration = n.duration ?? state.duration;
  renderNow();
  renderList();
});

refreshState();
const poll = setInterval(refreshState, 900);
window.addEventListener("unload", () => clearInterval(poll));
