const audio = document.getElementById("player");

let lastReport = 0;

function syncToBackground(extra = {}) {
  chrome.runtime.sendMessage({
    type: "OFFSCREEN_SYNC",
    currentTime: audio.currentTime,
    duration: audio.duration || 0,
    paused: audio.paused,
    ...extra,
  });
}

audio.addEventListener("timeupdate", () => {
  const now = Date.now();
  if (now - lastReport < 800) return;
  lastReport = now;
  syncToBackground();
});

audio.addEventListener("play", () => syncToBackground({ paused: false }));
audio.addEventListener("pause", () => syncToBackground({ paused: true }));
audio.addEventListener("loadedmetadata", () => syncToBackground());

audio.addEventListener("ended", () => {
  chrome.runtime.sendMessage({ type: "TRACK_ENDED" });
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.target !== "offscreen") return;

  if (msg.type === "LOAD_PLAY") {
    audio.src = msg.url;
    audio.play().then(() => {
      syncToBackground({ paused: false });
      sendResponse({ ok: true });
    }).catch((e) => {
      sendResponse({ ok: false, error: String(e) });
    });
    return true;
  }

  if (msg.type === "PAUSE") {
    audio.pause();
    syncToBackground({ paused: true });
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === "RESUME") {
    audio.play().then(() => {
      syncToBackground({ paused: false });
      sendResponse({ ok: true });
    }).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }

  if (msg.type === "SEEK") {
    const dur = Number.isFinite(audio.duration) ? audio.duration : 0;
    let t = Number(msg.time);
    if (!Number.isFinite(t)) t = 0;
    if (dur > 0) t = Math.max(0, Math.min(t, dur));

    const shouldPlay = !audio.paused;
    audio.currentTime = t;
    if (shouldPlay) {
      audio
        .play()
        .then(() => {
          syncToBackground({ paused: false });
          sendResponse({ ok: true });
        })
        .catch(() => {
          syncToBackground();
          sendResponse({ ok: true });
        });
      return true;
    }
    syncToBackground();
    sendResponse({ ok: true });
    return false;
  }

  return false;
});
