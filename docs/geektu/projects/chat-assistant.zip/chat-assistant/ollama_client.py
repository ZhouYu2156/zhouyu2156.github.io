import os
from typing import Literal

import ollama

from terminal_style import (
    format_history_block,
    print_assistant_stream_end,
    print_assistant_stream_start,
)

DEFAULT_SYSTEM = '你是一个乐于助人的助手，用户问什么问题，你都可以毫无保留的回答用户。'

HELP_TEXT = """可用指令：
/bye     退出
/help    显示本帮助
/clear   清空聊天记录（保留当前系统提示词）
/history 查看当前聊天记录
/model   查看或切换模型（/model 或 /model 模型名）
/system  查看或设置系统提示词（/system 或 /system 提示词内容）
"""

ReplyKind = Literal['exit', 'help', 'success', 'info', 'error', 'history']


class Assistant:
    """基于 Ollama 的 CLI 助手，支持斜杠指令与会话管理。"""

    def __init__(self) -> None:
        self.model = os.getenv('MODEL') or 'qwen3:8b'
        self.messages: list[dict[str, str]] = [
            {'role': 'system', 'content': DEFAULT_SYSTEM}
        ]

    def _system_index(self) -> int:
        for i, m in enumerate(self.messages):
            if m.get('role') == 'system':
                return i
        return -1

    def _get_system_prompt(self) -> str:
        idx = self._system_index()
        if idx >= 0:
            return self.messages[idx]['content']
        return DEFAULT_SYSTEM

    def _set_system_prompt(self, content: str) -> None:
        idx = self._system_index()
        if idx >= 0:
            self.messages[idx] = {'role': 'system', 'content': content}
        else:
            self.messages.insert(0, {'role': 'system', 'content': content})

    def _reset_conversation(self) -> None:
        system = self._get_system_prompt()
        self.messages = [{'role': 'system', 'content': system}]

    def _format_history(self) -> str:
        if len(self.messages) <= 1:
            return '（暂无对话记录，仅有系统提示词。）'
        lines: list[str] = []
        role_labels = {'system': '系统', 'user': '用户', 'assistant': '助手'}
        for m in self.messages:
            role = m.get('role', '')
            content = (m.get('content') or '').strip()
            label = role_labels.get(role, role)
            preview = content if len(content) <= 2000 else content[:2000] + '\n…（已截断）'
            lines.append(format_history_block(role, label, preview))
        return '\n'.join(lines).rstrip()

    def handle_command(
        self, raw: str,
    ) -> tuple[bool, bool, str, ReplyKind | None]:
        """
        处理以 `/` 开头的指令行。

        返回:
            handled: 是否为已识别（含未知）的指令
            should_exit: 是否应结束主循环（/bye）
            text: 需打印给用户的说明（可为空）
            kind: 终端语义颜色类型；非指令时为 None
        """
        text = raw.strip()
        if not text.startswith('/'):
            return False, False, '', None

        parts = text.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ''

        if cmd == '/bye':
            return True, True, '再见。', 'exit'
        if cmd == '/help':
            return True, False, HELP_TEXT, 'help'
        if cmd == '/clear':
            self._reset_conversation()
            return True, False, '已清空聊天记录（系统提示词已保留）。', 'success'
        if cmd == '/history':
            body = self._format_history()
            hist_kind: ReplyKind = (
                'info' if body == '（暂无对话记录，仅有系统提示词。）' else 'history'
            )
            return True, False, body, hist_kind
        if cmd == '/model':
            if not arg:
                return True, False, f'当前模型: {self.model}', 'info'
            self.model = arg
            return True, False, f'已切换模型为: {self.model}', 'success'
        if cmd == '/system':
            if not arg:
                return True, False, f'当前系统提示词:\n{self._get_system_prompt()}', 'info'
            self._set_system_prompt(arg)
            self._reset_conversation()
            return True, False, '已更新系统提示词，并清空对话上下文。', 'success'

        return True, False, f'未知指令: {cmd}，输入 /help 查看帮助。', 'error'

    def chat(self, message: str) -> str:
        self.messages.append({'role': 'user', 'content': message})
        stream = ollama.chat(
            model=self.model,
            messages=self.messages,
            stream=True,
        )
        parts: list[str] = []
        print_assistant_stream_start()
        for chunk in stream:
            content = (chunk.get('message') or {}).get('content') or ''
            if content:
                print(content, end='', flush=True)
                parts.append(content)
        print_assistant_stream_end()

        full_content = ''.join(parts)
        self.messages.append({'role': 'assistant', 'content': full_content})
        return full_content
