import dotenv

from ollama_client import Assistant
from terminal_style import init_cli, input_prompt, print_hint, print_semantic

dotenv.load_dotenv()


def main() -> None:
    init_cli()
    assistant = Assistant()
    print_hint('黄色=帮助 · 绿色=成功/助手输出 · 青色=信息 · 红色=错误 · 品红=退出；输入 /help 查看指令。')
    while True:
        message = input(input_prompt()).strip()
        if not message:
            continue

        handled, should_exit, reply, kind = assistant.handle_command(message)
        if should_exit:
            if reply and kind:
                print_semantic(kind, reply)
            break
        if handled:
            if reply and kind:
                print_semantic(kind, reply)
            print()
            continue

        assistant.chat(message)
        print()


if __name__ == '__main__':
    main()
