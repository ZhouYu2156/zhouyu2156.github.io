"""
终端语义颜色（colorama）。

python:3.12-slim 等最小镜像不包含 colorama，必须在 requirements.txt 中声明，
并由 Dockerfile 的 pip install 安装。
"""
from __future__ import annotations

from colorama import Fore, Style, init

_initialized = False


def init_cli() -> None:
    """尽早调用：在 Windows 上把 ANSI 转到控制台，并统一 autoreset 行为。"""
    global _initialized
    if not _initialized:
        init(autoreset=True)
        _initialized = True


def input_prompt() -> str:
    """主输入行：青色强调提示，斜杠指令用低对比灰提示。"""
    return (
        f"{Fore.CYAN}{Style.BRIGHT}> {Style.NORMAL}{Fore.LIGHTCYAN_EX}"
        f"输入内容或指令{Fore.LIGHTBLACK_EX}{Style.DIM}"
        f"（/help 帮助 · /bye 退出）{Style.RESET_ALL} "
    )


def print_hint(text: str) -> None:
    print(f"{Fore.LIGHTBLACK_EX}{Style.DIM}{text}{Style.RESET_ALL}")


def print_semantic(kind: str, text: str) -> None:
    """按语义打印整块文本（多行同理）。history 已在字符串内带 ANSI，不再外包一层颜色。"""
    if kind == "history":
        print(text)
        return
    prefix = {
        "exit": f"{Fore.MAGENTA}{Style.BRIGHT}",
        "help": f"{Fore.YELLOW}",
        "success": f"{Fore.GREEN}",
        "info": f"{Fore.CYAN}",
        "error": f"{Fore.RED}{Style.BRIGHT}",
    }.get(kind, "")
    print(f"{prefix}{text}{Style.RESET_ALL}")


def format_history_block(role: str, label: str, body: str) -> str:
    """单条历史：角色标签与正文颜色区分。"""
    head = {
        "system": (Fore.BLUE, Style.BRIGHT),
        "user": (Fore.YELLOW, Style.BRIGHT),
        "assistant": (Fore.LIGHTGREEN_EX, Style.BRIGHT),
    }.get(role, (Fore.WHITE, Style.NORMAL))
    fg, st = head
    line = f"{st}{fg}[{label}]{Style.RESET_ALL}\n{Fore.LIGHTWHITE_EX}{body}{Style.RESET_ALL}"
    return line


def print_assistant_stream_start() -> None:
    print(f"{Fore.LIGHTGREEN_EX}", end="", flush=True)


def print_assistant_stream_end() -> None:
    print(f"{Style.RESET_ALL}", flush=True)
