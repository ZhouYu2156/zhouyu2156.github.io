# CLI 聊天机器人

## 1. 前置条件

- 🤖 安装 `ollama`

```bash
ollama run qwen3:8b
```

- 🐍 安装 `python` 环境

```bash
python -m venv venv
source venv/bin/activate
```

- 🐳 若安装 `docker` 与 `docker compose`，可按下面**三步**启动 Ollama 与助手（推荐）

```bash
cd assistant
docker compose up -d ollama
docker compose exec ollama ollama pull qwen3:8b
docker compose run --rm assistant
```

（模型名可按需替换；也可通过环境变量 `MODEL` 指定，与 `.env` 一致。）

## 2. 使用指南

### 📦 安装依赖

依赖中包含 `colorama`（官方 `python:3.12-slim` 等最小镜像**不会**预装，Docker 构建时会通过 `pip install -r requirements.txt` 自动安装）。

```bash
pip install -r requirements.txt
```

### 💻 运行程序

```bash
python assistant.py
```

### 📝 聊天指令说明

```bash
/bye 退出
/help 帮助
/clear 清空聊天记录
/history 查看聊天记录
/model 切换模型
/system 设置系统提示词
```

### 🚀 支持 `docker compose` 运行

步骤见上文「前置条件」中的三行命令；首次需执行 `pull` 下载模型。
